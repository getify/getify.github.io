// copy in your "ex2.js" or "ex2-fixed.js" code
